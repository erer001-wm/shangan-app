# 生成安卓 APK 安装包（不用装 Android Studio）

## 原理
本文件夹是一个最小的安卓工程，里面用 WebView 直接打开 `index.html`（已经把你的备考工作台打包进去了）。
我们借助你已有的 GitHub 仓库 `erer001-wm/shangan-app` 的 **GitHub Actions 免费云构建**，几分钟自动编译出 APK，你下载安装即可。
**全程不需要在本机装任何开发工具。**

## 文件清单
```
apk-app/
├─ android/                          # 安卓工程（WebView 加载 index.html）
│  ├─ settings.gradle
│  ├─ build.gradle
│  └─ app/
│     ├─ build.gradle
│     └─ src/main/
│        ├─ AndroidManifest.xml       # 含相机/存储/网络权限、竖屏、桌面图标
│        ├─ java/com/beikao/app/MainActivity.java  # WebView 主界面，支持拍照选图、放开跨域
│        ├─ res/values/strings.xml
│        ├─ res/values/themes.xml
│        ├─ res/drawable/ic_launcher.xml  # 红色图标
│        └─ assets/index.html         # 备考工作台本体
└─ .github/workflows/build-apk.yml   # 自动构建脚本（云端打包 APK）
```

## 步骤一：把文件上传到 GitHub 仓库
打开 https://github.com/erer001-wm/shangan-app

**最省事（推荐）：用 GitHub Desktop**
1. 电脑装 GitHub Desktop（https://desktop.github.com/），登录你的 `erer001-wm` 账号。
2. 把本机已克隆的 `shangan-app` 仓库「Add」进来（File → Clone repository）。
3. 把本文件夹里的 `android/` 和 `.github/` 两个文件夹，**整个复制**到仓库根目录里。
4. 左侧勾选所有变更 → 写 `add android project` → **Commit to main** → **Push origin**。

**没有 GitHub Desktop 就用手动方式**
1. 在仓库页点「Add file → Upload files」，把 `android/` 文件夹下的文件逐个上传（注意保留 `android/app/src/main/...` 的目录层级）。
2. 同样上传 `.github/workflows/build-apk.yml`。
3. 提交。

> 注意：仓库根目录原本的 `index.html`（给网页版用的）要保留，别删，APK 构建会自动复制它进 app。

## 步骤二：一键云端打包
1. 仓库页顶部点 **Actions**（操作）。
2. 左侧看到 **Build APK** → 点进去 → 右侧 **Run workflow**（运行工作流）→ 确认。
3. 等 3–6 分钟，状态变绿色 ✅。
4. 点进该次运行 → 底部 **Artifacts** 区下载 `beikao-app-apk`（里面就是 `app-debug.apk`）。

## 步骤三：手机安装
1. 把 `app-debug.apk` 发到安卓手机（微信/数据线/网盘都行）。
2. 手机允许「未知来源」安装（设置里对浏览器/文件管理器开启）。
3. 点 APK 安装 → 桌面出现「备考工作台」图标。
4. 打开即用，**完全离线**，不依赖任何网址。

## 数据同步
- 云同步：APP 内「☁️ 云同步」选 Gitee，填仓库 `erer001-wm/shangan`、分支 `master`、令牌 → 上传/下载。
- 离线备份（最稳）：用「💾 导出备份 / 📂 导入备份」按钮，json 只在自己设备间传。

## 以后更新应用
改完 `index.html` 后，重新按上面步骤推到仓库 → 再 Run workflow → 下载新 APK 覆盖安装即可。
